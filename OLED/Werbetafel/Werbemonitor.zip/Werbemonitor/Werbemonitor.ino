/*
  Project: Werbetafel auf 0,96"-TFT Display mit 80x160 Pixeln
  Author: Michael Todtenbier
  Date: Created 04.03.2026
  Version: V1.3
  IDE: Arduino IDE 1.8.19
 
  Sketch:                   Michael Todtenbier
  Passende Platine:         Michael Todtenbier
  Anleitung im Wiki:        https://wiki.mobaledlib.de/anleitungen/oled/werbetafel
                            Bitte beachten!
  Thanks to:                Juergen Mueller (fuer die schoene Idee)
                            PaulRB, West Yorkshire, UK
                            https://forum.arduino.cc/t/two-or-more-different-tfts-with-one-arduino-nano-and-one-sd-card-reader/1388622
                            Microsoft Copilot & ChatGPT

                            
  Release 04. Maerz 2026 Michael Todtenbier
  ========================================

- Bugfix "Einfrieren" behoben
  > Ursachen fuer das Einfrieren wurden beim ueberpruefen des alten Sketchs in folgenden Teilen gefunden
    - die Zentrierung erzeugt negative Werte, wenn die Bilder breiter als 80px sind
    - ⁠die Laenge der Dateinamen ist auf 15 beschraenkt
    - ⁠unterschiedliche Schreibweise BMP, bmp, Bmp ist fehleranfaellig
    - ⁠fehlende Pruefung ungueltiger BMP-Dateien
    - versteckte Dateien anderer Betriebssysteme (z. B. macOS)
    - Pin 10 nicht auf High gesetzt
    - while (!Serial) { } blockiert
  > Da all diese Teile potentielle Ursachen fuer das Einfrieren sind, wurde der komplette Sketch verworfen und neu geschrieben.
    - Bilder werden nun links oben ausgerichtet, da die Zentrierung nicht mit jeder Hardware zuverlaessig laeuft. 
      Bilder sind im Grafikprogramm auf die entsprechenden Groessen auszuschneiden (80x160px fuer 0,96"; 128x160px fuer 1,8")
    - die Laenge der Dateinamen wurde auf 63 Zeichen erhoeht
    - unterschiedliche Schreibweisen der Dateiendung werden geprueft und in allen Formen akzeptiert
    - Der Sketch verfuegt ueber eine neue Komponente, die die BMP-Dateien auf Richtigkeit prueft (Windows-BMP, 24 bit)
      Entspricht die Datei nicht den Vorgaben, wird sie ignoriert.
      JPG oder PNG-Dateien duerfen auf der SD-Karte gespeichert sein. Sie werden nicht gelesen.
    - versteckte Dateien, die z. B. von macOS geschrieben werden, filtert der Sketch ebenso aus
    - alle Pins werden im Sketch auf High gesetzt, unabhaengig von der Nutzung als Display-Ausgang
    - Arduino-Typ wird abgefragt

- Neue Funktion "Rotation"
  > bisher gab es nur zwei Zustaende in der Rotation > 0 und 2
    Bei unguenstiger Einbaulage fehlten die anderen beiden Zustaende
    > nun kann man die Drehung in Grad angeben (0, 90, 180 oder 270)
    > Portrait und Landscape ermittelt der Sketch nun automatisch aus der Rotation

- Verbesserte Uebersichtlichkeit
  Alle Funktionen verfuegen nun ueber geeignete Headlines (Dank an ChatGPT)

- Neue Serial Prints
  Die BMP-Pruefung gibt die Ergebnisse klar definiert am seriellen Monitor aus.
  Auch wenn die Dateien uebersprungen werden, so kann man hier sehen, was falsch gemacht wurde.
    
  Release 17. Juli 2025 Juergen Mueller
  =====================================
- Vereinfachte Nutzung von 0.96er TFT oder 1.8er Display mit SD-Karte oder Mini-SD-Kartenleser auf der Rueckseite
  Es muss nur in der Zeile #define Display der Wert geaendert werden, dann werden die Einstellungen fuers Display vom Sketch uebernommen.
     
*/


#include <SPI.h>
#include <SD.h>
#include <TFT.h>

// ---------------- Display-Typ auswaehlen ----------------
// 96  = 0.96" TFT (ST7735, meist GREENTAB, invertiert)
// 180 = 1.8" TFT mit SD-Karte (ST7735, GREENTAB)
// 181 = 1.8" TFT mit Mini-SD auf Rueckseite (ST7735, BLACKTAB)
  #define Display 96

// ---------------- Rotation sauber definieren ----------------
// Offizielle Rotationswerte der Library (0..3) + bequeme Grad-Definition:
  #define ROT_0    0     // 0°
  #define ROT_90   1     // 90° clockwise
  #define ROT_180  2     // 180°
  #define ROT_270  3     // 270°

#define DISPLAY_ROTATION_DEG  0    // <- HIER bequem 0, 90, 180 oder 270 einstellen

// Mapping Grad -> Library-Rotation
  #if   (DISPLAY_ROTATION_DEG == 0)
    #define DISPLAY_ROTATION ROT_0
  #elif (DISPLAY_ROTATION_DEG == 90)
    #define DISPLAY_ROTATION ROT_90
  #elif (DISPLAY_ROTATION_DEG == 180)
    #define DISPLAY_ROTATION ROT_180
  #elif (DISPLAY_ROTATION_DEG == 270)
    #define DISPLAY_ROTATION ROT_270
  #else
    #error "DISPLAY_ROTATION_DEG muss 0, 90, 180 oder 270 sein."
  #endif

// ---------------- Native Aufloesung des Panels ----------------
// Fuer ST7735-Displays (0.96" und 1.8") sind 128x160 typisch.
// Hinweis im Original: 1.8" -> X=128, Y=160.
  #define PANEL_X 128
  #define PANEL_Y 160

// ---------------- Abgeleitete Aufloesung abhaengig von Rotation ----------------
// setRotation(0/2) = "Portrait" (128x160), setRotation(1/3) = "Landscape" (160x128).
  #if (DISPLAY_ROTATION == ROT_0) || (DISPLAY_ROTATION == ROT_180)
    #define XRES PANEL_X
    #define YRES PANEL_Y
  #else
    #define XRES PANEL_Y
    #define YRES PANEL_X
  #endif

// ---------------- Delay zwischen Bildern (ms) ----------------
  #define DELAY_IMAGE_SWAP 2000            // Anzeigedauer in Millisekunden (addiert sich bei mehreren Displays)
  
  #define PIN_TFT_CS0 2   
  #define PIN_TFT_CS1 3
  #define PIN_TFT_CS2 5
  #define PIN_TFT_CS3 6
  #define PIN_TFT_CS4 7
  #define PIN_TFT_CS5 10
  #define PIN_TFT_CS6 A0
  #define PIN_TFT_CS7 A1
  #define PIN_TFT_CS8 A2
  #define PIN_TFT_CS9 A3
  #define PIN_TFT_CS10 A4
  #define PIN_TFT_CS11 A5
  
  #define PIN_SD_CS 4
  #define PIN_DC 9
  #define PIN_RST 8
  
/*
 Der Speicher des Arduinos laesst maximal zehn Displays zu. Die Schaltung ist bewusst mit sechs Ausgaengen ausgestattet.
 Somit koennen statt 5 Doppel-Displays alternativ 6 Einzeldisplays betrieben werden.
 In jedem der 6 Stecker sind jeweils zwei CS-Leitungen mit dem Arduino verbunden. Die gleichzeitige Nutzung aller 12 CS-Leitungen ist nicht moeglich.
 */
 
// ---------------- Anzahl der Displays ----------------
  #define SCREENS 2                                                  // Die hier definierte Zahl muss zu der Anzahl der aktivierten Displays passen (hier 1+2)
  
  TFT TFTscreen[SCREENS] = {
    TFT(PIN_TFT_CS0, PIN_DC, PIN_RST), // 1st Display  (CS1/JST1)    // Im Auslieferungszustand sind die beiden Displays 1+2 aktiviert
    TFT(PIN_TFT_CS1, PIN_DC, -1),      // 2nd Display  (CS2/JST1)
  //TFT(PIN_TFT_CS2, PIN_DC, -1),      // 3rd Display  (CS1/JST2)    // Die folgenden Displays sind deaktiviert und muessen durch entfernen von "//" zunaechst aktiviert werden.
  //TFT(PIN_TFT_CS3, PIN_DC, -1),      // 4th Display  (CS2/JST2)
  //TFT(PIN_TFT_CS4, PIN_DC, -1),      // 5th Display  (CS1/JST3)
  //TFT(PIN_TFT_CS5, PIN_DC, -1),      // 6th Display  (CS2/JST3)
  //TFT(PIN_TFT_CS6, PIN_DC, -1),      // 7th Display  (CS1/JST4)
  //TFT(PIN_TFT_CS7, PIN_DC, -1),      // 8th Display  (CS2/JST4)
  //TFT(PIN_TFT_CS8, PIN_DC, -1),      // 9th Display  (CS1/JST5)
  //TFT(PIN_TFT_CS9, PIN_DC, -1),      // 10th Display (CS2/JST5)
  //TFT(PIN_TFT_CS10, PIN_DC, -1),     // 11th Display (CS1/JST6)
  //TFT(PIN_TFT_CS11, PIN_DC, -1)      // 12th Display (CS2/JST6)
  };

void setup() {
  // ---------- Serielle Konsole ----------
  Serial.begin(9600);
  // Auf Boards mit nativem USB (Leonardo/Micro/SAMD) warten; auf UNO/Nano nicht blockieren
  #if defined(ARDUINO_ARCH_SAMD) || defined(ARDUINO_AVR_LEONARDO)
    while (!Serial) { }
  #endif

  // ---------- SPI / CS-Grundstellung ----------
  // SS/Master-Pin (D10) immer als OUTPUT, damit SPI im Master-Modus bleibt
  pinMode(10, OUTPUT);
  digitalWrite(10, HIGH);

  // Alle potenziellen CS-Pins als OUTPUT/HIGH (deasserted).
  // -> Auch ungenutzte CS-Leitungen hochziehen, um Schweben zu vermeiden.
  const uint8_t allCsPins[] = {
    PIN_SD_CS,
    PIN_TFT_CS0, PIN_TFT_CS1, PIN_TFT_CS2, PIN_TFT_CS3,
    PIN_TFT_CS4, PIN_TFT_CS5, // Achtung: PIN_TFT_CS5 ist D10 (SS) – erneut HIGH ist ok.
    PIN_TFT_CS6, PIN_TFT_CS7, PIN_TFT_CS8, PIN_TFT_CS9,
    PIN_TFT_CS10, PIN_TFT_CS11
  };
  for (uint8_t i = 0; i < sizeof(allCsPins); i++) {
    pinMode(allCsPins[i], OUTPUT);
    digitalWrite(allCsPins[i], HIGH);
  }

  // ---------- SD-Karte initialisieren ----------
  init_SD();   // nutzt SD.begin(PIN_SD_CS) aus der bestehenden Funktion

  // ---------- TFT-Displays initialisieren ----------
  for (byte s = 0; s < SCREENS; s++) {

    // Display-Typ-spezifische Initialisierung
    if (Display == 96) {
      TFTscreen[s].initR(INITR_GREENTAB);
      TFTscreen[s].invertDisplay(1);
    } else if (Display == 180) {
      TFTscreen[s].initR(INITR_GREENTAB);
      TFTscreen[s].invertDisplay(0);
    } else if (Display == 181) {
      TFTscreen[s].initR(INITR_BLACKTAB);
      TFTscreen[s].invertDisplay(0);
    } else {
      // Fallback, falls 'Display' außerhalb 96/180/181 liegt
      TFTscreen[s].initR(INITR_GREENTAB);
      TFTscreen[s].invertDisplay(0);
    }

    // Rotation aus dem neuen Rotations-Block verwenden
    TFTscreen[s].setRotation(DISPLAY_ROTATION);

    // Bildschirm loeschen (schwarz)
    TFTscreen[s].background(0, 0, 0);
  }

  Serial.println(F("Setup abgeschlossen."));
}


void init_SD() {
  Serial.print(F("SD card init..."));
  if (!SD.begin(PIN_SD_CS)) {
    Serial.println(F("ERROR")); // failed
    return;
  }
  Serial.println(F("SUCCESS")); // ok
}


// Prueft, ob die Datei ein unterstuetztes 24-Bit, unkomprimiertes, bottom-up BMP ist.
// Gibt bei Problemen false zurueck, damit die Datei uebersprungen werden kann.
bool isSupportedBMP(const char* path) {
  File f = SD.open(path, FILE_READ);
  if (!f) {
    Serial.println(F("BMP-Check: Datei konnte nicht geoeffnet werden."));
    return false;
  }

  uint8_t hdr[54];
  int r = f.read(hdr, sizeof(hdr));
  f.close();
  if (r != 54) {
    Serial.println(F("BMP-Check: Header hat nicht 54 Bytes."));
    return false;
  }

  // Signatur 'BM'
  if (hdr[0] != 'B' || hdr[1] != 'M') {
    Serial.println(F("BMP-Check: Keine 'BM'-Signatur."));
    return false;
  }

  // Sicheres Little-Endian-Parsing via memcpy
  auto rd16 = [&](int off) {
    uint16_t v; memcpy(&v, &hdr[off], sizeof(v)); return v;
  };
  auto rd32 = [&](int off) {
    uint32_t v; memcpy(&v, &hdr[off], sizeof(v)); return v;
  };
  auto rd32s = [&](int off) {
    int32_t v; memcpy(&v, &hdr[off], sizeof(v)); return v;
  };

  uint32_t dibSize = rd32(14);
  int32_t  width   = rd32s(18);
  int32_t  height  = rd32s(22);
  uint16_t planes  = rd16(26);
  uint16_t bpp     = rd16(28);
  uint32_t comp    = rd32(30);

  if (planes != 1) {
    Serial.println(F("BMP-Check: planes != 1."));
    return false;
  }
  if (bpp != 24) {
    Serial.println(F("BMP-Check: Nur 24-bit BMPs werden unterstuetzt."));
    return false;
  }
  if (comp != 0) {
    Serial.println(F("BMP-Check: Komprimierte BMPs werden nicht unterstuetzt."));
    return false;
  }
  if (height < 0) {
    Serial.println(F("BMP-Check: Top-down BMPs (negative Hoehe) nicht unterstuetzt."));
    return false;
  }
  if (width <= 0 || height <= 0) {
    Serial.println(F("BMP-Check: Unplausible Bildgroesse."));
    return false;
  }

  // Optionales Limit, um Ausreisser frueh abzulehnen (kannst du anpassen/entfernen):
  if (width > 320 || height > 320) {
    Serial.println(F("BMP-Check: Bild zu gross (>320)."));
    return false;
  }

  // DIB-Groeße koennte z. B. 40 (BITMAPINFOHEADER) sein – das ist ok. Wir pruefen hier nicht strenger.
  (void)dibSize;

  return true;
}


void loop() {
  static byte s = 0;

  File dir = SD.open("/");
  if (!dir) {
    Serial.println(F("Root-Verzeichnis konnte nicht geoeffnet werden."));
    return;
  }

  File entry;
  bool worked_once = false;

  while (true) {
    entry = dir.openNextFile();
    if (!entry) break;  // Ende des Verzeichnisses

    if (entry.isDirectory()) {
      entry.close();
      continue;         // Unterordner ignorieren
    }

    const char* srcName = entry.name();

    // Sicher kopieren, falls wir den Namen nach entry.close() noch brauchen
    char name[64];
    strncpy(name, srcName, sizeof(name) - 1);
    name[sizeof(name) - 1] = '\0';

    Serial.print(F("Opened File: "));
    Serial.println(name);

    // Dateiendung .bmp/.BMP/.BmP... case-insensitive pruefen
    auto hasBMPExt = [](const char* fn) {
      int n = strlen(fn);
      if (n < 4) return false;
      char e1 = tolower(fn[n - 3]);
      char e2 = tolower(fn[n - 2]);
      char e3 = tolower(fn[n - 1]);
      return (fn[n - 4] == '.') && e1 == 'b' && e2 == 'm' && e3 == 'p';
    };

    if (!hasBMPExt(name)) {
      Serial.println(F("Keine BMP-Grafik!"));
      entry.close();
      continue;
    }

    // WICHTIG: Header pruefen, ungeeignete BMPs ueberspringen
    entry.close();  // wir oeffnen die Datei in isSupportedBMP() und spaeter in loadImage() erneut
    if (!isSupportedBMP(name)) {
      Serial.println(F("BMP nicht unterstuetzt -> uebersprungen."));
      continue;
    }

    // Jetzt erst laden
    PImage image = TFTscreen[s].loadImage(name);
    if (!image.isValid()) {
      Serial.println(F("Bild ungueltig -> uebersprungen."));
      image.close();
      continue;
    }

    int w = image.width();
    int h = image.height();

    // Zentrierung mit Clamping: nie negative Koordinaten
    int x = (w <= XRES) ? (XRES - w) / 2 : 0;
    int y = (h <= YRES) ? (YRES - h) / 2 : 0;

    Serial.print(F("Render: "));
    Serial.print(name);
    Serial.print(F("  size "));
    Serial.print(w);
    Serial.print('x');
    Serial.println(h);

    TFTscreen[s].image(image, x, y);
    image.close();

    worked_once = true;
    delay(DELAY_IMAGE_SWAP);

    s++;
    if (s >= SCREENS) s = 0;
  }

  dir.close();

  if (!worked_once) {
    Serial.println(F("Kein Bild dargestellt. SD wird neu initialisiert..."));
    SD.end();
    init_SD();
  }
}
