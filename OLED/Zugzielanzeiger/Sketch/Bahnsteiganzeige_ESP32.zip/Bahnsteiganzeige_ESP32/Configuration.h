// --------------------------------------------------------------------------------------------
// Pin-Zuordnungen am ESP32, Werte für Zugzielanzeiger Steuerung v3 (nicht ändern)
// --------------------------------------------------------------------------------------------
// Attention don't use for the buttons
// GPIO 0, 2         Boot Mode
//      1, 3         Rs232
//      6-11         Internal used
//      22, 23       I2C
//      34-36, 39    No PullUp

#define BUTTON0_PIN             12      // Activate the next text message from Flash fo the current OLED
#define BUTTON1_PIN             14      // Switch to the next OLED
#define BUTTON2_PIN             27      // Next text message for OLED 0
#define BUTTON3_PIN             26      //   "           "            1
#define BUTTON4_PIN             25      //   "           "            2
#define BUTTON5_PIN             33      //   "           "            2

#define DCC_SIGNAL_PIN          39      // Connected to the opto coppler which reads the DCC signals (ESP32 Tested with; 36, 39, 34, 35, 32, 13)

#define LED_HEARTBEAT_PIN       2       // Define the pin for the heartbeat LED = Build_in_LED

#define RESET_DISP_PIN          32      // Reset PIN for the OLED Displays if used with Hardis OLED Adapter
#define UNUSED_AIN_PIN          A3      // This analog input is used to generate a random initial value for the random() function

// --------------------------------------------------------------------------------------------
// Baudrate und Debug-Nachrichten
// --------------------------------------------------------------------------------------------
#define SERIAL_BAUDRATE         115200  // Attention the serial monitor of the Arduino IDE must use the same baud rate

#define _PRINT_DEBUG_MESSAGES   1        // Set to 1 to print debug messages
