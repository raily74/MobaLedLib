// --------------------------------------------------------------------------------------------
// WLAN-Einstellungen
// --------------------------------------------------------------------------------------------
const char* ssid = "MobaLedLib";
const char* password = "1234567890";
const char* hostname = "ZZA_Entenhausen";

// --------------------------------------------------------------------------------------------
// DCC-Einstellungen
// --------------------------------------------------------------------------------------------
#define USE_DCC                 1     // FLASH Usage: 4014 (13%), RAM 70 Byte 02.02.19:
#define FIRST_DCC_ADDR          300   // First used DCC accessory message

// --------------------------------------------------------------------------------------------
// Display-Rotation
// --------------------------------------------------------------------------------------------
#define DISPLAY_ROT         U8G2_R2   // U8G2_R0: Normal, U8G2_R2: Display rotated (180 degree clockwise rotation)
                                      // U8G2_R2 is twice as fast // U8G2_R2 is twice as fast

// --------------------------------------------------------------------------------------------
// Zufall aktivieren
// --------------------------------------------------------------------------------------------
//#define RAND_CHANGE_MINTIME    20   // Minimal time between two display changes [s]
//#define RAND_CHANGE_MAXTIME    60   // Maximal time between two display changes [s]

// --------------------------------------------------------------------------------------------
// Gleisgruppen verwenden
// --------------------------------------------------------------------------------------------
#define RAIL_NR_GROUPS          1     // Groups the Displays by the Rail number of rail groups.
                                      // All Displays with the same number are accessed with the same
                                      // command and show the same text.
                                      // Attention: Rows must be sorted so that rows with the same
                                      //            rail number follow each other.

// --------------------------------------------------------------------------------------------
// Gleis > Pin-Zuordnungen
// --------------------------------------------------------------------------------------------
#define USE_I2C_MUX             1
#if USE_I2C_MUX
  #define I2C_MUX_CHIPS         4      // Number of TCA9548A chips used
  const PROGMEM                        // Mux Rail Side
  Rail_Cfg_T Rail_Cfg[] = {//Ch  Nr
         { 0, "1",  'L' },
         { 4, "1",  'L' },
         { 8, "1",  'L' },
         { 12, "1",  'L' },
         { 2, "1",  'R' },
         { 6, "1",  'R' },
         { 10, "1",  'R' },
         { 14, "1",  'R' },
         { 3, "2",  'L' },
         { 7, "2",  'L' },
         { 11, "2",  'L' },
         { 15, "2",  'L' },
         { 1, "2",  'R' },
         { 5, "2",  'R' },
         { 9, "2",  'R' },
         { 13, "2",  'R' },
         { 16, "3",  'L' },
         { 18, "3",  'R' },
         { 19, "4",  'L' },
         { 17, "4",  'R' },
     };

#else                      // Old Nano based board: Used when USE_I2C_MUX is disabled
  const PROGMEM            //Pin Rail Side
  Rail_Cfg_T Rail_Cfg[] = {//Nr  Nr
                            { 9, "1", 'R' },
                            {10, "2", 'L' },
                            {11, "3", 'R' },
                            {12, "4", 'L' },  // and add additional lines if more then 3 pannels are used
     };
#endif

// --------------------------------------------------------------------------------------------
// Zugziele (TextMessages)
// --------------------------------------------------------------------------------------------
#define START_LINE_CHAR '\247' // paragraph symbol
#define NEXT_ENTRY_CHAR '|'
#define SL              "\247" // Start Line   (Paragraph symbol)
#define NE              "|"    // Next Entry

// Abhängig vom dem Zeichensatz des Editors werden die deutschen Umlaute richtig dargestellt oder nicht ;-(
// Es ist es besser, wenn hier immer die folgenden Codes anstelle der Umlaute verwendtet werden.
// Dann kommt jeder Editor damit zurecht.
//
// Umlaute ersetzten laut folgender Chiffre. Dazu können Hex Codes (0xE4) oder Octal Codes (\344) verwendet werden
// Die oktalen Codes enthalten immer 3 Ziffern. Dadurch können diese besser zusammen mit darauffolgenden
// Ziffern verwendet werden.
//   ä  = \344   ö  = \366   ü  = \374
//   Ä  = \304   Ö  = \326   Ü  = \334
//   ß  = \337   ½  = \275   ¾  = \276
//   È  = \310   È  = \311   Ê  = \312
//   à  = \340   á  = \341   â  = \341
//   À  = \300   Á  = \301   Â  = \302
//   @  = \100   |  = \174   ~  = \176
//
// Würzburg ist daher W\374rzburg
// Verspätung ist daher Versp\344tung

#define G934 "#G9 ¾|11:00"    // Gleis '9 3/4' at '11:00'
#define G999 "#G999|00:00"    // Gleis 999 um 00:00 Uhr

// Attention: The sequence of the entries must match with the sequence in the array Dat[]
//            "lauftext" is an exception to this sequence. This is handled in function
//            Short_Mode_Next_ProcState()

const PROGMEM char Text_Messages[] =
    //        Uhrzeit      Zugnummer     Ziel                   Zuglauf1                      Zuglauf2                  Wagenstand   Lauftext
/*1*/     SL "22:24"   NE "ICE 153"   NE "Mainz Hbf"   NE "Schlier \374ber"   NE "Karlsruhe nach"   NE "-222F--"   NE "+++ Vorsicht: STUMMI-ICE f\344hrt durch +++      +++ Danke an Michael, Tobias, Klaus & Fredddy,... +++"
/*2*/     SL "09:34"   NE "RB 1521"   NE "Aschaffenburg"   NE "Gro\337auheim - Kahl"   NE "- Gro\337krotzenburg"   NE ""   NE ""
/*3*/     SL "10:04"   NE "RB 3237"   NE "Plattling"   NE "Freising - Moosburg"   NE "- Landshut"   NE ""   NE ""
/*4*/     SL "12:53"   NE "EC 172"   NE "Hamburg - Altona"   NE "Berlin Hbf -"   NE "Hamburg Hbf"   NE "-222211"   NE "Versp\344tung ca. 10 Min."
/*5*/     SL "15:21"   NE "ICE 592"   NE "Berlin Ostbf"   NE "Fulda - Kassel -"   NE "Braunschweig Hbf"   NE "11111"   NE ""
/*6*/     SL "17:02"   NE "IC 602"   NE "Puttgarden"   NE "Wuppertal - Dortmund"   NE "Bremen - Hamburg"   NE "22111"   NE ""
/*7*/     SL "18:30"   NE "RE 7"   NE "Kiel / Flensburg"   NE "Elmshorn -"   NE "Neum\374nster"   NE "2121"   NE "Zugteilung in Neum\374nster - Vorderer Zugteil f\344hrt bis Flensburg"
/*8*/     SL G934   NE "Hg-Exp"   NE "Hogsmeade"   NE "King's Cross"   NE "- nonstop -"   NE "-------"   NE "Hogwarts-Express"
/*9*/     SL "21:45"   NE "ICE 651"   NE "Leipzig Hbf"   NE "Fulda - Eisenach"   NE ""   NE ""   NE "Achtung: Heute auf Gleis 7"
/*10*/     SL "10:46"   NE "RB5"   NE "Fulda"   NE "Melsungen -"   NE "Bebra"   NE "--22F--"   NE ""
/*11*/     SL "05:12"   NE "ICE 101"   NE "M\374nchen Hbf"   NE "Augsburg - Ulm"   NE "Stuttgart - Mannheim"   NE "-222F--"   NE ""
/*12*/     SL "05:24"   NE "RE 1502"   NE "Frankfurt Hbf"   NE "Offenbach - Hanau"   NE "Aschaffenburg"   NE "22111"   NE ""
/*13*/     SL "05:37"   NE "RB 2213"   NE "Koblenz Hbf"   NE "Andernach - Remagen"   NE "Bonn Hbf"   NE "2111"   NE ""
/*14*/     SL "05:50"   NE "ICE 702"   NE "Berlin Hbf"   NE "Leipzig - Bitterfeld"   NE "Dessau - Potsdam"   NE "11111"   NE ""
/*15*/     SL "06:05"   NE "IC 831"   NE "Hamburg Hbf"   NE "Hannover - Uelzen"   NE "L\374neburg"   NE "22211"   NE ""
/*16*/     SL "06:16"   NE "EC 172"   NE "Z\374rich HB"   NE "Basel SBB - Freiburg"   NE "Offenburg-Karlsruhe"   NE "-222211"   NE "Versp\344tung ca. 10 Min."
/*17*/     SL "06:27"   NE "RB 1457"   NE "Regensburg"   NE "Neufahrn - Landshut"   NE "Plattling"   NE ""   NE ""
/*18*/     SL "06:35"   NE "S 7"   NE "Wiesbaden Hbf"   NE "Mainz-Kastel -"   NE "Hochheim-Fl\366rsh."   NE ""   NE ""
/*19*/     SL "06:42"   NE ""   NE "Dresden Hbf"   NE "Riesa - Coswig"   NE "Mei\337en"   NE "-F222--"   NE "Achtung: Wagenreihung ge\344ndert"
/*20*/     SL "06:55"   NE "RE 3421"   NE ""   NE "Marburg - Gie\337en"   NE "Friedberg-Frankf."   NE ""   NE ""
/*21*/     SL "07:10"   NE "IC 612"   NE "Bremen Hbf"   NE "Osnabr\374ck - Diepholz"   NE "Delmenhorst"   NE "22111"   NE ""
/*22*/     SL "07:24"   NE "RB 317"   NE "Heidelberg Hbf"   NE "Wiesloch - Walldorf"   NE "Schwetzingen"   NE ""   NE ""
/*23*/     SL "07:37"   NE "ICE 815"   NE "K\366ln Hbf"   NE "Montabaur - Limburg"   NE "Siegburg/Bonn"   NE "12211"   NE "Heute ohne Halt in Siegburg"
/*24*/     SL "07:49"   NE "RE 9"   NE "Aachen Hbf"   NE "Herzogenrath -"   NE "Stolberg (Rhld)"   NE ""   NE ""
/*25*/     SL "08:00"   NE "S 1"   NE "Dortmund Hbf"   NE "Bochum - Essen"   NE "Duisburg"   NE ""   NE ""
/*26*/     SL "08:13"   NE "ICE 455"   NE "Mainz Hbf"   NE "Mannheim - Worms"   NE "Bingen"   NE "F222--"   NE "+++ Danke f\374r Ihre Reise mit der DB +++"
/*27*/     SL "08:25"   NE "IC 284"   NE "Stralsund"   NE "Greifswald - Ribnitz"   NE "Rostock"   NE "22211"   NE ""
/*28*/     SL "08:39"   NE "RE 1207"   NE "Freiburg (Brsg)"   NE "Offenburg - Lahr"   NE "Emmendingen"   NE ""   NE ""
/*29*/     SL "08:50"   NE "RB 1302"   NE "Fulda"   NE "Hanau - Gelnhausen"   NE "Schl\374chtern"   NE ""   NE ""
/*30*/     SL "09:04"   NE "ICE 223"   NE "Hannover Hbf"   NE "Kassel - G\366ttingen"   NE "Hildesheim"   NE "-F-222-"   NE "Versp\344tung ca. 5 Min."
/*31*/     SL "09:15"   NE "IC 713"   NE "Erfurt Hbf"   NE "Weimar - Apolda"   NE "Naumburg"   NE "22111"   NE ""
/*32*/     SL "09:27"   NE "RB 2421"   NE "Cottbus"   NE "L\374bbenau - L\374bben"   NE "K\366nigs Wusterh."   NE ""   NE ""
/*33*/     SL "09:40"   NE "RE 522"   NE "Magdeburg Hbf"   NE ""   NE "Oschersleben"   NE ""   NE ""
/*34*/     SL "09:55"   NE "ICE 999"   NE "Paris Est"   NE "Saarbr\374cken - Metz"   NE "Champagne-Ardenne"   NE "F-222--"   NE "Bienvenue \340 bord"
/*35*/     SL "10:08"   NE "RB 912"   NE "Bamberg"   NE "Forchheim - Erlangen"   NE "F\374rth"   NE ""   NE ""
/*36*/     SL "10:21"   NE "IC 451"   NE "Kiel Hbf"   NE "Neum\374nster - Itzehoe"   NE "Elmshorn"   NE "2121"   NE "Zugteilung in Neum\374nster"
/*37*/     SL "10:36"   NE "RE 3305"   NE "Saarbr\374cken"   NE "Kaiserslautern -"   NE "Neunkirchen (Saar)"   NE ""   NE ""
/*38*/     SL "10:48"   NE "ICE 732"   NE "Basel SBB"   NE "Freiburg - L\366rrach"   NE "Weil am Rhein"   NE "222211"   NE ""
/*39*/     SL "11:00"   NE "RB 3002"   NE "Passau"   NE ""   NE "Vilshofen"   NE ""   NE ""
/*40*/     SL G934   NE "Hg-Exp"   NE "Hogsmeade"   NE "King's Cross"   NE "- nonstop -"   NE "-------"   NE "Hogwarts-Express"
/*41*/     SL "11:18"   NE "RE 17"   NE "Emden Hbf"   NE "Leer - Oldenburg"   NE "Bremen"   NE ""   NE ""
/*42*/     SL "11:31"   NE "ICE 163"   NE "D\374sseldorf Hbf"   NE "K\366ln - Leverkusen"   NE "Duisburg - Essen"   NE "F-222--"   NE "Achtung: Heute Wagen am Zugschluss"
/*43*/     SL "11:45"   NE "IC 390"   NE "Stuttgart Hbf"   NE "Pforzheim - Bruchsal"   NE "Heilbronn"   NE "22211"   NE ""
/*44*/     SL "12:00"   NE "RB 814"   NE "Coburg"   NE "Sonneberg - Eisfeld"   NE "Hildburghausen"   NE ""   NE ""
/*45*/     SL "12:14"   NE "RE 3214"   NE "Ingolstadt Hbf"   NE ""   NE "M\374nchen"   NE ""   NE ""
/*46*/     SL "12:27"   NE "ICE 456"   NE "Lindau-Insel"   NE "Kempten - Immenstadt"   NE "Oberstdorf"   NE "-2222--"   NE ""
/*47*/     SL "12:39"   NE "IC 845"   NE "Karlsruhe Hbf"   NE "Mannheim - Bruchsal"   NE "Baden-Baden"   NE "21111"   NE ""
/*48*/     SL "12:52"   NE "RB 1105"   NE "Rosenheim"   NE "Grafing - Prien"   NE "Bernau-Traunstein"   NE ""   NE ""
/*49*/     SL "13:07"   NE "RE 7"   NE "Flensburg"   NE "Neum\374nster -"   NE "Schleswig"   NE "2121"   NE "Zugteilung in Neum\374nster"
/*50*/     SL "13:20"   NE "ICE 234"   NE "Amsterdam"   NE "Oberhausen - Arnhem"   NE "Utrecht"   NE "-2222--"   NE "Welcome aboard ICE International"
/*51*/     SL "13:33"   NE "IC 281"   NE "Garmisch"   NE "Murnau - Oberau"   NE "Farchant"   NE "22211"   NE ""
/*52*/     SL "13:46"   NE "RB 606"   NE "Trier Hbf"   NE "Wittlich - Bullay"   NE "Cochem - Koblenz"   NE ""   NE ""
/*53*/     SL "14:02"   NE "RE 4101"   NE "Offenburg"   NE "Kehl - Strasbourg"   NE ""   NE ""   NE "Bienvenue \340 Strasbourg"
/*54*/     SL "14:17"   NE "ICE 812"   NE "Br\374ssel Midi"   NE "Aachen - Li\350ge"   NE "Leuven"   NE "F-222--"   NE ""
/*55*/     SL "14:33"   NE "IC 127"   NE "Salzburg Hbf"   NE "M\374nchen - Rosenheim"   NE "Freilassing"   NE "22211"   NE ""
/*56*/     SL "14:48"   NE "RB 1703"   NE "Gie\337en"   NE "Friedberg - Butzbach"   NE "Langg\366ns"   NE ""   NE ""
/*57*/     SL "15:02"   NE "RE 9"   NE "Siegen"   NE "Betzdorf - Kirchen"   NE "Freudenberg"   NE ""   NE ""
/*58*/     SL "15:19"   NE "ICE 555"   NE "Dresden Hbf"   NE "Leipzig - Riesa"   NE "Coswig"   NE "-F222--"   NE "Bitte beachten: neuer Wagenstand"
/*59*/     SL "15:35"   NE "IC 920"   NE "Warnem\374nde"   NE "Rostock - Bentwisch"   NE "Ribnitz-Damgarten"   NE "22111"   NE ""
/*60*/     SL "15:50"   NE "RB 1910"   NE "Konstanz"   NE "Radolfzell - Singen"   NE "Schaffhausen"   NE ""   NE ""
/*61*/     SL "16:05"   NE "RE 2207"   NE "Paderborn"   NE "Warburg - Kassel"   NE "Hann. M\374nden"   NE ""   NE ""
/*62*/     SL "16:20"   NE "ICE 876"   NE "Z\374rich HB"   NE "Stuttgart - Ulm"   NE "Lindau"   NE "222211"   NE "Bitte Platzreservierung beachten"
/*63*/     SL "16:35"   NE "IC 502"   NE "Oldenburg"   NE "Bremen - Delmenhorst"   NE "Bad Zwischenahn"   NE "2211"   NE ""
/*64*/     SL "16:49"   NE "RB 2204"   NE "Wismar"   NE ""   NE "Grevesm\374hlen"   NE ""   NE ""
/*65*/     SL "17:05"   NE "RE 801"   NE "Zwickau"   NE "Chemnitz - Glauchau"   NE "Meerane"   NE ""   NE ""
/*66*/     SL "17:21"   NE ""   NE "Hamburg Hbf"   NE "Bremen - Rotenburg"   NE "Harburg"   NE "-222F--"   NE "Achtung: Heute auf Gleis 12"
/*67*/     SL "17:36"   NE "IC 173"   NE ""   NE "Frankfurt (Oder)"   NE "F\374rstenwalde"   NE "21111"   NE ""
/*68*/     SL "17:50"   NE "RB 1411"   NE "Detmold"   NE "Bad Salzuflen -"   NE "Lemgo"   NE ""   NE ""
/*69*/     SL "18:05"   NE "RE 2315"   NE "Bielefeld"   NE "Herford - Minden"   NE "Bad Oeynhausen"   NE ""   NE ""
/*70*/     SL "18:20"   NE ""   NE "Wien Hbf"   NE "Passau - Linz"   NE "St. P\366lten"   NE "-F-222-"   NE "Willkommen in \326sterreich"
/*71*/     SL "18:35"   NE "IC 240"   NE "L\374beck"   NE "B\374chen - Hamburg"   NE "Reinfeld"   NE "22211"   NE ""
/*72*/     SL "18:49"   NE "RB 1209"   NE "Hildesheim"   NE "Alfeld - Elze"   NE "Sarstedt"   NE ""   NE ""
/*73*/     SL "19:02"   NE "RE 300"   NE "Minden"   NE ""   NE "B\374ckeburg"   NE ""   NE ""
/*74*/     SL "19:15"   NE "ICE 401"   NE "London"   NE "Br\374ssel - Lille"   NE "Calais-Eurotunnel"   NE "222211"   NE "Welcome to the Eurostar-ICE"
/*75*/     SL "19:30"   NE "IC 600"   NE "N\374rnberg Hbf"   NE "Bamberg - Erlangen"   NE "F\374rth"   NE "22211"   NE ""
/*76*/     SL "19:45"   NE "RB 1415"   NE "Ulm Hbf"   NE "Geislingen-G\366ppingen"   NE "Esslingen"   NE ""   NE ""
/*77*/     SL "20:00"   NE "RE 220"   NE "Frankfurt Hbf"   NE "Wiesbaden - Mainz"   NE "Gro\337-Gerau"   NE ""   NE ""
/*78*/     SL "20:14"   NE ""   NE "Kopenhagen"   NE "Hamburg - Flensburg"   NE "Odense"   NE "-2222--"   NE "Velkommen ombord"
/*79*/     SL "20:30"   NE "IC 870"   NE "Szczecin"   NE ""   NE "Prenzlau"   NE "22111"   NE ""
/*80*/     SL "20:44"   NE "RB 3333"   NE "Marburg"   NE "Gie\337en - Lollar"   NE "Friedelhausen"   NE ""   NE ""
/*81*/     SL "21:00"   NE "RE 99"   NE "Fulda"   NE "Hanau - Gelnhausen"   NE "Schl\374chtern"   NE ""   NE ""
/*82*/     SL "21:15"   NE ""   NE "Entenhausen"   NE "Duckburg"   NE "Onkel Dagobert"   NE "-222F--"   NE "Sonderfahrt nach Entenhausen"
/*83*/     SL "21:30"   NE "IC 715"   NE "Graz"   NE ""   NE "Leoben"   NE "22211"   NE ""
/*84*/     SL "21:44"   NE "RB 808"   NE "Bayreuth"   NE "Pegnitz - Lauf"   NE "N\374rnberg"   NE ""   NE ""
/*85*/     SL "21:59"   NE "RE 1201"   NE "Chemnitz"   NE "Glauchau - Limbach"   NE "Hohenstein"   NE ""   NE ""
/*86*/     SL "22:15"   NE "ICE 651"   NE "Leipzig Hbf"   NE "Fulda - Eisenach"   NE ""   NE ""   NE ""
/*87*/     SL "22:28"   NE "RB 1722"   NE "Bad Hersfeld"   NE "Fulda - H\374nfeld"   NE "Bebra"   NE ""   NE ""
/*88*/     SL "22:41"   NE "RE 4109"   NE "Westerland"   NE "Hamburg - Husum"   NE "Nieb\374ll"   NE ""   NE "Sylt Shuttle bereit"
/*89*/     SL "22:55"   NE ""   NE "Z\374rich HB"   NE "Basel - Singen"   NE "Konstanz"   NE "-222F--"   NE "Bitte beachten: Wagenreihung"
/*90*/     SL "23:07"   NE "IC 351"   NE "Saarbr\374cken"   NE "Kaiserslautern -"   NE "Homburg (Saar)"   NE "22111"   NE ""
/*91*/     SL "23:20"   NE "RB 5001"   NE "Garmisch"   NE "Murnau - Oberau"   NE "Farchant"   NE ""   NE ""
/*92*/     SL "23:33"   NE "RE 2904"   NE "Bremerhaven"   NE "Bremen - Osterholz"   NE "Stubben"   NE ""   NE ""
/*93*/     SL "23:46"   NE "ICE 141"   NE "Stuttgart Hbf"   NE "Mannheim - Karlsruhe"   NE "Pforzheim"   NE "11111"   NE ""
/*94*/     SL "23:59"   NE "IC 907"   NE "Rostock Hbf"   NE "Berlin - Neustrelitz"   NE "G\374strow"   NE "22211"   NE ""
/*95*/     SL "00:12"   NE "RB 2208"   NE "L\374neburg"   NE ""   NE "Hamburg"   NE ""   NE ""
/*96*/     SL "00:25"   NE "RE 1313"   NE "Bamberg"   NE "Forchheim - Erlangen"   NE "N\374rnberg"   NE ""   NE ""
/*97*/     SL "00:39"   NE "ICE 703"   NE "Berlin Hbf"   NE "Frankfurt (Oder)"   NE "Cottbus"   NE "F-222--"   NE ""
/*98*/     SL "00:52"   NE "IC 812"   NE "Frankfurt Hbf"   NE "Mainz - Bingen"   NE "Bad Kreuznach"   NE "22111"   NE ""
/*99*/     SL "01:07"   NE "RB 1708"   NE "Minden"   NE "Bad Oeynhausen -"   NE "B\374ckeburg"   NE ""   NE ""
/*100*/     SL "01:21"   NE "RE 3201"   NE "Magdeburg Hbf"   NE "Burg - Genthin"   NE "Stendal"   NE ""   NE ""
/*101*/     SL "01:36"   NE "ICE 815"   NE "Hannover Hbf"   NE "Kassel - G\366ttingen"   NE "Braunschweig"   NE "222211"   NE ""
/*102*/     SL "01:50"   NE "IC 211"   NE "Karlsruhe Hbf"   NE ""   NE "Rastatt"   NE "22211"   NE ""
/*103*/     SL "02:03"   NE "RB 903"   NE "Regensburg"   NE "Landshut - Moosburg"   NE "Freising"   NE ""   NE ""
/*104*/     SL "02:15"   NE "RE 18"   NE "Dortmund Hbf"   NE "Hamm - Unna"   NE "Kamen"   NE ""   NE ""
/*105*/     SL "02:28"   NE "ICE 204"   NE "Leipzig Hbf"   NE "Halle - Wei\337enfels"   NE "Naumburg"   NE "-F222--"   NE "Versp\344tung ca 15 Min"
/*106*/     SL "02:42"   NE "IC 722"   NE "Freiburg (Brsg)"   NE "Offenburg - Lahr"   NE "Emmendingen"   NE "22111"   NE ""
/*107*/     SL "02:55"   NE "RB 1301"   NE "Kassel Hbf"   NE "Fritzlar - Wabern"   NE "Borken"   NE ""   NE ""
/*108*/     SL "03:08"   NE "RE 401"   NE "Flensburg"   NE "Neum\374nster-Rendsb."   NE "Schleswig"   NE ""   NE ""
/*109*/     SL "03:20"   NE ""   NE "Paris Est"   NE "Forbach - Metz"   NE "Nancy"   NE "222211"   NE "Bienvenue \340 bord"
/*110*/     SL "03:34"   NE "IC 671"   NE "M\374nchen Hbf"   NE "Augsburg-Donauw\366rth"   NE "Ingolstadt"   NE "F222--"   NE ""
/*111*/     SL "03:47"   NE "RB 2805"   NE "Wuppertal Hbf"   NE "Essen - Velbert"   NE "Remscheid"   NE ""   NE ""
/*112*/     SL "04:01"   NE "RE 332"   NE "Erfurt Hbf"   NE "Weimar - Apolda"   NE "Jena"   NE ""   NE ""
/*113*/     SL "04:16"   NE "ICE 900"   NE "Hamburg-Altona"   NE "Kiel - Neum\374nster"   NE "Elmshorn"   NE "-2222--"   NE ""
/*114*/     SL "04:29"   NE "IC 505"   NE "Zwickau"   NE "Chemnitz - Glauchau"   NE "Meerane"   NE "22111"   NE ""
/*115*/     SL "04:44"   NE "RB 1210"   NE "Kiel Hbf"   NE "Pl\366n - Preetz"   NE "Schwentinental"   NE ""   NE ""
/*116*/     SL "04:59"   NE "RE 19"   NE "G\366rlitz"   NE "Dresden - Bautzen"   NE "L\366bau"   NE ""   NE ""
/*117*/     SL "05:13"   NE ""   NE "Mailand Centrale"   NE "Chiasso - Lugano"   NE "Como"   NE "-222F--"   NE "Benvenuti \340 bordo"
/*118*/     SL "05:27"   NE "IC 470"   NE "Hannover Hbf"   NE "Hildesheim - Alfeld"   NE "G\366ttingen"   NE "22211"   NE ""
/*119*/     SL "05:40"   NE "RB 312"   NE "Friedrichshafen"   NE "Ulm - Ravensburg"   NE "Markdorf"   NE ""   NE ""
/*120*/     SL "05:55"   NE "RE 2407"   NE "Fulda"   NE "Bad Hersfeld -"   NE "Eisenach"   NE ""   NE ""
/*121*/     SL "06:09"   NE "ICE 881"   NE "Wien Hbf"   NE "St. P\366lten - Linz"   NE "Amstetten"   NE "11111"   NE "Willkommen in \326sterreich"
/*122*/     SL "06:22"   NE "IC 343"   NE "Bremen Hbf"   NE ""   NE "Oldenburg"   NE "22211"   NE ""
/*123*/     SL "06:36"   NE "RB 1511"   NE "Essen Hbf"   NE "M\374lheim - Oberhausen"   NE "Duisburg"   NE ""   NE ""
/*124*/     SL "06:49"   NE "RE 3502"   NE "Koblenz Hbf"   NE "Mainz - Bingen"   NE "Oberwesel"   NE ""   NE ""
/*125*/     SL "07:02"   NE "ICE 444"   NE "Berlin Hbf"   NE "Dessau - Potsdam"   NE "Spandau"   NE "-F-222-"   NE ""
/*126*/     SL "07:15"   NE "IC 901"   NE "Wiesbaden"   NE "Mainz - Ingelheim"   NE "Bingen"   NE "21111"   NE ""
/*127*/     SL "07:28"   NE "RB 1217"   NE "Offenburg"   NE "Kehl - Strasbourg"   NE ""   NE ""   NE "Bienvenue \340 Strasbourg"
/*128*/     SL "07:42"   NE "RE 2104"   NE "Konstanz"   NE "Singen - Radolfzell"   NE "Allensbach"   NE ""   NE ""
/*129*/     SL "07:55"   NE ""   NE "Tatooine"   NE "Mos Eisley"   NE "Anchorhead"   NE "-222F--"   NE "Galactic Express nach Tatooine"
/*130*/     SL "08:09"   NE "IC 765"   NE "Kiel Hbf"   NE ""   NE "Rendsburg"   NE "22211"   NE ""
/*131*/     SL "08:22"   NE "RB 202"   NE "Celle"   NE "Gifhorn - Meinersen"   NE "Braunschweig"   NE ""   NE ""
/*132*/     SL "08:36"   NE "RE 1211"   NE "Osnabr\374ck"   NE "Ibbenb\374ren-Lengerich"   NE "M\374nster"   NE ""   NE ""
/*133*/     SL "08:50"   NE "ICE 250"   NE "Kopenhagen"   NE "Odense - Ringsted"   NE "Roskilde"   NE "-2222--"   NE "Velkommen ombord"
/*134*/     SL "09:04"   NE "IC 140"   NE "Berlin Ostbf"   NE "Frankfurt (Oder)"   NE "Moskau (\077)"   NE "22111"   NE "Sonderzug weiter nach Moskau"
/*135*/     SL "09:19"   NE "RB 3330"   NE "Limburg"   NE "Wiesbaden - Idstein"   NE "Niedernhausen"   NE ""   NE ""
/*136*/     SL "09:33"   NE "RB 1412"   NE "Hanau Hbf"   NE "Offenbach - Maintal"   NE "Gro\337krotzenburg"   NE ""   NE ""
/*137*/     SL "09:48"   NE "RE 2202"   NE "Suhl"   NE ""   NE "Arnstadt"   NE ""   NE ""
/*138*/     SL "10:02"   NE ""   NE "Hamburg Hbf"   NE "Kiel - Neum\374nster"   NE "Elmshorn"   NE "-222F--"   NE "Heute ge\344nderte Wagenreihung"
/*139*/     SL "10:15"   NE "IC 341"   NE "Frankfurt Hbf"   NE "Gie\337en - Friedberg"   NE "Hanau"   NE "22111"   NE ""
/*140*/     SL "10:30"   NE "RB 1123"   NE "Weiden"   NE "Schwandorf - Nabburg"   NE "Neukirchen"   NE ""   NE ""
/*141*/     SL "10:44"   NE "RE 1608"   NE "Aalen"   NE "Schw\344bisch Gm\374nd"   NE "Stuttgart"   NE ""   NE ""
/*142*/     SL "10:59"   NE "ICE 990"   NE "Z\374rich HB"   NE "Basel - Freiburg"   NE "Ka - Mannheim"   NE "222211"   NE ""
/*143*/     SL "11:13"   NE "IC 760"   NE "M\374nchen Hbf"   NE ""   NE "Ingolstadt"   NE "F222--"   NE ""
/*144*/     SL "11:27"   NE "RB 3401"   NE "Detmold"   NE ""   NE "Horn-Bad Meinberg"   NE ""   NE ""
/*145*/     SL "11:42"   NE "RE 1415"   NE ""   NE "Warburg - Hofgeismar"   NE "Grebenstein"   NE ""   NE ""
/*146*/     SL "11:55"   NE "ICE 703"   NE "Dresden Hbf"   NE "Leipzig - Riesa"   NE "Coswig"   NE "-2222--"   NE "Versp\344tung ca. 5 Min."
/*147*/     SL "12:08"   NE "IC 540"   NE "Kiel Hbf"   NE ""   NE "Neum\374nster"   NE "22211"   NE ""
/*148*/     SL "12:22"   NE "RB 911"   NE "Freiburg (Brsg)"   NE "Emmendingen - Lahr"   NE "Offenburg"   NE ""   NE ""
/*149*/     SL "12:35"   NE "RE 4405"   NE "Bonn Hbf"   NE "K\366ln - Br\374hl"   NE "Remagen"   NE ""   NE ""
/*150*/     SL "12:49"   NE ""   NE "Stuttgart Hbf"   NE ""   NE "Karlsruhe"   NE "11111"   NE ""
/*151*/     SL "13:02"   NE "IC 293"   NE "Rostock"   NE "Neubrandenb.-G\374strow"   NE "Bad Doberan"   NE "22211"   NE ""
/*152*/     SL "13:16"   NE "RB 3302"   NE "Fulda"   NE "Schl\374chtern-Steinau"   NE "W\344chtersbach"   NE ""   NE ""
/*153*/     SL "13:30"   NE "RE 220"   NE "Mainz Hbf"   NE "Ingelheim - Bingen"   NE "Bad Kreuznach"   NE ""   NE ""
/*154*/     SL "13:45"   NE "ICE 612"   NE "Paris Est"   NE "Saarbr\374cken - Metz"   NE "Nancy"   NE "F-222--"   NE "Bienvenue \340 bord"
/*155*/     SL "13:59"   NE "IC 455"   NE "Erfurt Hbf"   NE "Weimar - Naumburg"   NE "Jena"   NE "22111"   NE ""
/*156*/     SL "14:12"   NE "RB 1811"   NE "Bamberg"   NE "Forchheim - Erlangen"   NE "F\374rth"   NE ""   NE ""
/*157*/     SL "14:27"   NE "RE 3907"   NE "Offenburg"   NE "Kehl - Strasbourg"   NE ""   NE ""   NE "Bienvenue \340 Strasbourg"
/*158*/     SL "14:41"   NE ""   NE "Wien Hbf"   NE "Linz - St. P\366lten"   NE "Amstetten"   NE "-222F--"   NE "Willkommen in \326sterreich"
/*159*/     SL "14:55"   NE "IC 880"   NE "Saarlouis"   NE "Dillingen-V\366lklingen"   NE "Saarbr\374cken"   NE "22211"   NE ""
/*160*/     SL "15:09"   NE "RB 2105"   NE "Paderborn"   NE "Kassel - Warburg"   NE "Brakel"   NE ""   NE ""
/*161*/     SL "15:23"   NE "RE 707"   NE "Kiel Hbf"   NE ""   NE "Flensburg"   NE ""   NE ""
/*162*/     SL "15:38"   NE "ICE 333"   NE "Amsterdam"   NE "Utrecht - Arnhem"   NE "Oberhausen"   NE "-F222--"   NE "Welcome aboard ICE International"
/*163*/     SL "15:52"   NE "IC 340"   NE "G\366rlitz"   NE "Bautzen - Dresden"   NE "L\366bau"   NE "22111"   NE ""
/*164*/     SL "16:07"   NE "RB 2002"   NE "Cuxhaven"   NE ""   NE "Bremen"   NE ""   NE ""
/*165*/     SL "16:20"   NE "RE 1808"   NE "Bayreuth"   NE "Pegnitz - Hersbruck"   NE "N\374rnberg"   NE ""   NE ""
/*166*/     SL "16:35"   NE ""   NE "Kopenhagen"   NE "Odense - Ringsted"   NE "Roskilde"   NE "222211"   NE "Velkommen ombord"
/*167*/     SL "16:49"   NE "IC 931"   NE "Oldenburg"   NE "Delmenhorst - Bremen"   NE "Bad Zwischenahn"   NE "22211"   NE ""
/*168*/     SL "17:02"   NE "RB 1508"   NE "Siegen"   NE "Betzdorf - Kirchen"   NE "Freudenberg"   NE ""   NE ""
/*169*/     SL "17:16"   NE "RE 5003"   NE "Bielefeld"   NE "Herford - Minden"   NE "Bad Oeynhausen"   NE ""   NE ""
/*170*/     SL "17:30"   NE ""   NE "London"   NE "Br\374ssel - Lille"   NE "Calais-Eurotunnel"   NE "-222F--"   NE "Welcome to the Eurostar-ICE"
/*171*/     SL "17:45"   NE "IC 780"   NE "Hannover Hbf"   NE ""   NE "Magdeburg"   NE "22211"   NE ""
/*172*/     SL "18:00"   NE "RB 1221"   NE "Darmstadt"   NE "Gro\337-Gerau - Mainz"   NE "R\374sselsheim"   NE ""   NE ""
/*173*/     SL "18:14"   NE "RE 1218"   NE "Cottbus"   NE "L\374bbenau - L\374bben"   NE "Berlin"   NE ""   NE ""
/*174*/     SL "18:28"   NE ""   NE "Entenhausen"   NE ""   NE "Onkel Dagobert"   NE "-222F--"   NE "Sonderfahrt nach Entenhausen"
/*175*/     SL "18:42"   NE "IC 611"   NE "Zwickau"   NE "Glauchau - Chemnitz"   NE "Meerane"   NE "22111"   NE ""
/*176*/     SL "18:57"   NE "RB 1419"   NE "Trier Hbf"   NE "Koblenz - Cochem"   NE "Wittlich"   NE ""   NE ""
/*177*/     SL "19:11"   NE "RE 2007"   NE "Saarbr\374cken"   NE ""   NE "Kaiserslautern"   NE ""   NE ""
/*178*/     SL "19:25"   NE ""   NE "Mordor"   NE ""   NE "Barad-d\374r"   NE "-2222--"   NE "Der eine Zug zum Herrschen"
/*179*/     SL "19:39"   NE "IC 473"   NE "Bremen Hbf"   NE "Diepholz - Osnabr\374ck"   NE "Oldenburg"   NE "22211"   NE ""
/*180*/     SL "19:52"   NE "RB 1813"   NE "Regensburg"   NE "Landshut - Moosburg"   NE "Freising"   NE ""   NE ""
/*181*/     SL "20:06"   NE "RE 310"   NE "Passau"   NE ""   NE "Vilshofen"   NE ""   NE ""
/*182*/     SL "20:20"   NE ""   NE "Br\374ssel Midi"   NE "Li\351ge - Leuven"   NE "Gent"   NE "-F-222-"   NE ""
/*183*/     SL "20:34"   NE "IC 221"   NE "Hamburg Hbf"   NE "L\374neburg - Uelzen"   NE "Hannover"   NE "22211"   NE ""
/*184*/     SL "20:48"   NE "RB 5007"   NE "Aschaffenburg"   NE "Kahl - Hanau"   NE "Frankfurt"   NE ""   NE ""
/*185*/     SL "21:02"   NE "RE 2311"   NE "Magdeburg Hbf"   NE "Stendal - Genthin"   NE "Burg"   NE ""   NE ""
/*186*/     SL "21:16"   NE ""   NE "Berlin Hbf"   NE "Dessau - Potsdam"   NE "Spandau"   NE "-222F--"   NE ""
/*187*/     SL "21:30"   NE "IC 314"   NE "W\374rzburg"   NE "Heilbronn - Lauda"   NE "Schweinfurt"   NE "22111"   NE ""
/*188*/     SL "21:44"   NE "RB 811"   NE "Offenburg"   NE "Lahr - Emmendingen"   NE "Freiburg (Brsg)"   NE ""   NE ""
/*189*/     SL "21:58"   NE "RE 3203"   NE "Rostock"   NE "G\374strow-Bad Doberan"   NE "Wismar"   NE ""   NE ""
/*190*/     SL "22:12"   NE ""   NE "Paris Est"   NE "Saarbr\374cken - Metz"   NE "Nancy"   NE "222211"   NE "Bienvenue \340 bord"
/*191*/     SL "22:25"   NE "IC 585"   NE "Kiel Hbf"   NE ""   NE "Flensburg"   NE "22211"   NE ""
/*192*/     SL "22:39"   NE "RB 1304"   NE "Duisburg"   NE "Essen - Bochum"   NE "Dortmund"   NE ""   NE ""
/*193*/     SL "22:53"   NE "RE 2109"   NE "Hildesheim"   NE "Sarstedt - Elze"   NE "Alfeld"   NE ""   NE ""
/*194*/     SL "23:07"   NE "ICE 201"   NE "Wien Hbf"   NE "St. P\366lten - Linz"   NE "Amstetten"   NE "-2222--"   NE "Willkommen in \326sterreich"
/*195*/     SL "23:20"   NE "IC 802"   NE "Hannover Hbf"   NE ""   NE "Magdeburg"   NE "22211"   NE ""
/*196*/     SL "23:34"   NE "RB 2005"   NE "Karlsruhe Hbf"   NE "Bruchsal - Mannheim"   NE "Heidelberg"   NE ""   NE ""
/*197*/     SL "23:48"   NE "RE 301"   NE "M\374nchen Hbf"   NE ""   NE "Ingolstadt"   NE ""   NE ""
/*198*/     SL "00:02"   NE ""   NE "Tatooine"   NE ""   NE "Anchorhead"   NE "-222F--"   NE "Hyperraum-Express nach Tatooine"
/*199*/     SL "00:16"   NE "IC 601"   NE "Dresden Hbf"   NE "Riesa - Leipzig"   NE "Bitterfeld"   NE "22211"   NE ""
/*200*/     SL "00:29"   NE "RB 1407"   NE "Coburg"   NE ""   NE "Bamberg"   NE ""   NE ""
/*201*/     SL "00:44"   NE "RE 4010"   NE "Koblenz Hbf"   NE "Andernach - Remagen"   NE "Bonn Hbf"   NE ""   NE ""
/*202*/     SL "00:58"   NE ""   NE "London"   NE "Br\374ssel - Lille"   NE "Calais - Eurotunnel"   NE "-2222--"   NE "Welcome to the Eurostar-ICE"
/*203*/     SL "01:11"   NE "IC 202"   NE "Freiburg (Brsg)"   NE "Lahr - Offenburg"   NE "Karlsruhe"   NE "22111"   NE ""
/*204*/     SL "01:25"   NE "RB 1902"   NE "Plattling"   NE "Landshut - Moosburg"   NE "Freising"   NE ""   NE ""
/*205*/     SL "01:40"   NE "RE 808"   NE "Flensburg"   NE ""   NE "Neum\374nster"   NE ""   NE ""
/*206*/     SL "01:54"   NE ""   NE "Mordor"   NE "Shire - Bree"   NE "Minas Morgul"   NE "-F-222-"   NE "Nur f\374r Ringtr\344ger"
/*207*/     SL "02:08"   NE "IC 777"   NE "Berlin Ostbf"   NE "F\374rstenwalde-F(Oder)"   NE "K\374strin"   NE "22211"   NE ""
/*208*/     SL "02:22"   NE "RB 8002"   NE "Passau"   NE ""   NE "Vilshofen"   NE ""   NE ""
/*209*/     SL "02:37"   NE "RE 902"   NE "Hamburg Hbf"   NE "L\374neburg - Uelzen"   NE "Hannover"   NE ""   NE ""
/*210*/     SL "02:51"   NE ""   NE "Kopenhagen"   NE "Odense - Ringsted"   NE "Roskilde"   NE "222211"   NE "Velkommen ombord"
/*211*/     SL "03:05"   NE "IC 355"   NE "Erfurt Hbf"   NE "Weimar - Naumburg"   NE "Jena"   NE "22211"   NE ""
/*212*/     SL "03:19"   NE "RB 1817"   NE "G\366ttingen"   NE "Kassel - Northeim"   NE "Northeim"   NE ""   NE ""
/*213*/     SL "03:33"   NE "RE 1803"   NE "Halle (Saale)"   NE "Wei\337enfels-Merseburg"   NE "Leipzig"   NE ""   NE ""
/*214*/     SL "03:47"   NE ""   NE "Entenhausen"   NE ""   NE "Daisy Town"   NE "-222F--"   NE "Sonderfahrt nach Entenhausen"
/*215*/     SL "04:01"   NE "IC 642"   NE "M\374nster"   NE "Dortmund - Hamm"   NE "Bielefeld"   NE "22211"   NE ""
/*216*/     SL "04:15"   NE "RB 6004"   NE "Lindau"   NE "Friedrichshafen-RV"   NE "Memmingen"   NE ""   NE ""
/*217*/     SL "00:01"   NE "IC 2025"   NE ""   NE "Berlin -"   NE "K\366ln -"   NE "1111111"   NE "Frohes neues Jahr w\374nscht die Deutsche Bahn\041"
/*218*/     SL "06:06"   NE "RB 1225"   NE "Weihnachtsmarkt"   NE "N\374rnberg -"   NE "Roth -"   NE ""   NE "Gl\374hwein und Lebkuchen im Bordbistro"
/*219*/     SL "07:07"   NE "S 4711"   NE "K\366lsch-Express"   NE "K\366ln Hbf -"   NE "Deutz"   NE "4444444"   NE "Alaaf\041 Heute Sonderfahrt zum Karneval"
/*220*/     SL "11:11"   NE "NAR 111"   NE "Narrenzug"   NE "Konstanz -"   NE "Villingen"   NE "3333333"   NE "Helau\041 Bitte Konfetti nicht auf die Gleise werfen"
/*221*/     SL "17:89"   NE "ICE 999"   NE "Zeitreise"   NE "Gestern -"   NE "Morgen"   NE "2222222"   NE "Achtung: Zeitumstellung, bitte Uhren kontrollieren"
/*222*/     SL "09:99"   NE "RB 404"   NE "Matrix"   NE "Realit\344t -"   NE "Illusion"   NE "0000000"   NE "Blaue oder rote Pille\077 Heute auf Gleis 4"
/*223*/     SL "20:15"   NE "IC 0815"   NE "Dinnerzug"   NE "Kochstudio -"   NE "Restaurantwagen"   NE "7777777"   NE "Heute Abend mit Sternekoch Tim in Wagen 5"
/*224*/     SL "13:37"   NE ""   NE "Hackerhausen"   NE "Serverstadt -"   NE "Cloud City"   NE "1234567"   NE "Root-Zug: Alle Ports ge\366ffnet"
/*225*/     SL "10:10"   NE "EC 1010"   NE "M\344rchenwald"   NE "Rotk\344ppchen -"   NE "Dornr\366schen"   NE "7654321"   NE "Bitte auf die sieben Zwerge achten"
/*226*/     SL "23:59"   NE ""   NE "Traumland"   NE "Kissenstadt -"   NE "Bettburg"   NE "222F--"   NE "Gute Nacht und angenehme Tr\344ume\041"
/*227*/     SL G999   NE "SND-Exp"   NE "Nordpol"   NE "Weihnachtsdorf -"   NE "Rentierhof"   NE "-------"   NE "Sonderfahrt mit dem Nikolaus"
/*228*/     SL "12:24"   NE ""   NE "Bethlehem"   NE "Nazareth -"   NE "Jerusalem"   NE "1111111"   NE "Frohe Weihnachten\041"
/*229*/     SL "05:55"   NE "RE 555"   NE "Pilgerzug"   NE "Lourdes -"   NE "Rom"   NE "2121212"   NE "Sonderfahrt f\374r Pilgergruppen"
/*230*/     SL "14:92"   NE "RB 1492"   NE "Santa Maria"   NE "Palos -"   NE "Neue Welt"   NE "1492149"   NE "Entdeckerzug: Christoph Kolumbus an Bord"
/*231*/     SL "20:24"   NE ""   NE "Silicon Valley"   NE "Berlin Startup -"   NE "San Francisco"   NE "2468246"   NE "Innovationszug: WLAN in Lichtgeschwindigkeit"
/*232*/     SL "07:31"   NE "RE 731"   NE "Mittelerde"   NE "Bruchtal -"   NE "Mordor"   NE "0000000"   NE "Bitte den Ring nicht verlieren"
/*233*/     SL "21:12"   NE "IC 2112"   NE "Rush City"   NE "Toronto -"   NE "YYZ"   NE "7777777"   NE "Limelight Express - nur heute\041"
/*234*/     SL "18:84"   NE "RB 1884"   NE ""   NE "Kupferstadt -"   NE "Dampfhausen"   NE "8848848"   NE "Heute mit Lokomobile und Messingwagen"
/*235*/     SL "16:61"   NE ""   NE "Mondbasis Alpha"   NE "Cape Canaveral -"   NE "Luna City"   NE "6616616"   NE "Schwerelosigkeit im Bordrestaurant"
/*236*/     SL "19:85"   NE "IC 1985"   NE "Hill Valley"   NE "Twin Pines -"   NE "Clock Tower"   NE "5555555"   NE "Zur\374ck in die Zukunft - Abfahrt exakt um 21:04\041"
/*237*/     SL "03:01"   NE "RE 1983"   NE "Ost-Berlin"   NE "Pankow \374ber"   NE "Amorbach"   NE "U240183"   NE "Sonderzug nach Pankow"

; // End of the Text_Messages string
