// --------------------------------------------------------------------------------------------
// WLAN-Einstellungen
// --------------------------------------------------------------------------------------------
#define USE_WIFI                0     // Must be set to 0 if no SSID and PWD is available.
const char* ssid = "";
const char* password = "";
const char* hostname = "";

// --------------------------------------------------------------------------------------------
// DCC-Einstellungen
// --------------------------------------------------------------------------------------------
#define USE_DCC                 1     // FLASH Usage: 4014 (13%), RAM 70 Byte 02.02.19:
#define FIRST_DCC_ADDR          100   // First used DCC accessory message

// --------------------------------------------------------------------------------------------
// Display-Rotation
// --------------------------------------------------------------------------------------------
#define DISPLAY_ROT         U8G2_R2   // U8G2_R0: Normal, U8G2_R2: Display rotated (180 degree clockwise rotation)
                                      // U8G2_R2 is twice as fast // U8G2_R2 is twice as fast

// --------------------------------------------------------------------------------------------
// Zufall aktivieren
// --------------------------------------------------------------------------------------------
//#define RAND_CHANGE_MINTIME    20   // Minimal time between two display changes [s]
//#define RAND_CHANGE_MAXTIME    60   // Maximal time between two display changes [s]

// --------------------------------------------------------------------------------------------
// Gleisgruppen verwenden
// --------------------------------------------------------------------------------------------
#define RAIL_NR_GROUPS          1     // Groups the Displays by the Rail number of rail groups.
                                      // All Displays with the same number are accessed with the same
                                      // command and show the same text.
                                      // Attention: Rows must be sorted so that rows with the same
                                      //            rail number follow each other.

// --------------------------------------------------------------------------------------------
// Gleis > Pin-Zuordnungen
// --------------------------------------------------------------------------------------------
#define USE_I2C_MUX             1
#if USE_I2C_MUX
  #define I2C_MUX_CHIPS         4      // Number of TCA9548A chips used
  const PROGMEM                        // Mux Rail Side
  Rail_Cfg_T Rail_Cfg[] = {//Ch  Nr
         { 0, "1",  'L' },
         { 4, "1",  'L' },
         { 8, "1",  'L' },
         { 2, "1",  'R' },
         { 6, "1",  'R' },
         { 10, "1",  'R' },
         { 3, "2",  'L' },
         { 7, "2",  'L' },
         { 11, "2",  'L' },
         { 1, "2",  'R' },
         { 5, "2",  'R' },
         { 9, "2",  'R' },
         { 12, "3",  'L' },
         { 16, "3",  'L' },
         { 20, "3",  'L' },
         { 14, "3",  'R' },
         { 18, "3",  'R' },
         { 22, "3",  'R' },
         { 15, "4",  'L' },
         { 19, "4",  'L' },
         { 23, "4",  'L' },
         { 13, "4",  'R' },
         { 17, "4",  'R' },
         { 21, "4",  'R' },
     };

#else                      // Old Nano based board: Used when USE_I2C_MUX is disabled
  const PROGMEM            //Pin Rail Side
  Rail_Cfg_T Rail_Cfg[] = {//Nr  Nr
                            { 9, "1", 'R' },
                            {10, "2", 'L' },
                            {11, "3", 'R' },
                            {12, "4", 'L' },  // and add additional lines if more then 3 pannels are used
     };
#endif

// --------------------------------------------------------------------------------------------
// Zugziele (TextMessages)
// --------------------------------------------------------------------------------------------
#define START_LINE_CHAR '\247' // paragraph symbol
#define NEXT_ENTRY_CHAR '|'
#define SL              "\247" // Start Line   (Paragraph symbol)
#define NE              "|"    // Next Entry

// Abhängig vom dem Zeichensatz des Editors werden die deutschen Umlaute richtig dargestellt oder nicht ;-(
// Es ist es besser, wenn hier immer die folgenden Codes anstelle der Umlaute verwendtet werden.
// Dann kommt jeder Editor damit zurecht.
//
// Umlaute ersetzten laut folgender Chiffre. Dazu können Hex Codes (0xE4) oder Octal Codes (\344) verwendet werden
// Die oktalen Codes enthalten immer 3 Ziffern. Dadurch können diese besser zusammen mit darauffolgenden
// Ziffern verwendet werden.
//   ä  = \344   ö  = \366   ü  = \374
//   Ä  = \304   Ö  = \326   Ü  = \334
//   ß  = \337   ½  = \275   ¾  = \276
//   È  = \310   È  = \311   Ê  = \312
//   à  = \340   á  = \341   â  = \341
//   À  = \300   Á  = \301   Â  = \302
//   @  = \100   |  = \174   ~  = \176
//
// Würzburg ist daher W\374rzburg
// Verspätung ist daher Versp\344tung

#define G934 "#G9 ¾|11:00"    // Gleis '9 3/4' at '11:00'
#define G999 "#G999|00:00"    // Gleis 999 um 00:00 Uhr

// Attention: The sequence of the entries must match with the sequence in the array Dat[]
//            "lauftext" is an exception to this sequence. This is handled in function
//            Short_Mode_Next_ProcState()

const PROGMEM char Text_Messages[] =
    //        Uhrzeit      Zugnummer     Ziel                   Zuglauf1                      Zuglauf2                  Wagenstand   Lauftext
/*1*/     SL "22:24"   NE "ICE 153"   NE "Mainz Hbf"   NE "Schlier \374ber"   NE "Karlsruhe nach"   NE "-222F--"   NE "+++ Vorsicht: STUMMI-ICE f\344hrt durch  +++  Danke an Hardi, Michael, Tobias, Klaus & Freddy,... +++"
/*2*/     SL "09:34"   NE "RB 1521"   NE "Aschaffenburg"   NE "Gro\337auheim - Kahl"   NE "- Gro\337krotzenburg"   NE ""   NE ""
/*3*/     SL "10:04"   NE "RB 3237"   NE "Plattling"   NE "Freising - Moosburg"   NE "- Landshut"   NE ""   NE ""
/*4*/     SL "12:53"   NE "EC 172"   NE "Hamburg - Altona"   NE "Berlin Hbf -"   NE "Hamburg Hbf"   NE "-222211"   NE "Versp\344tung ca. 10 Min."
/*5*/     SL "15:21"   NE "ICE 592"   NE "Berlin Ostbf"   NE "Fulda - Kassel -"   NE "Braunschweig Hbf"   NE "11111"   NE ""
/*6*/     SL "17:02"   NE "IC 602"   NE "Puttgarden"   NE "Wuppertal - Dortmund"   NE "Bremen - Hamburg"   NE "22111"   NE ""
/*7*/     SL "18:30"   NE "RE 7"   NE "Kiel / Flensburg"   NE "Elmshorn -"   NE "Neum\374nster"   NE "2121"   NE "Zugteilung in Neum\374nster - Vorderer Zugteil f\344hrt bis Flensburg"
/*8*/     SL G934   NE "Hg-Exp"   NE "Hogsmeade"   NE "King's Cross"   NE "- nonstop -"   NE "-------"   NE "Hogwarts-Express"
/*9*/     SL "21:45"   NE "ICE 651"   NE "Leipzig Hbf"   NE "Fulda - Eisenach"   NE ""   NE ""   NE "Achtung: Heute auf Gleis 7"
/*10*/     SL "10:25"   NE "RB 1025"   NE "Friedrichshafen"   NE "Freising - Moosburg"   NE "- Landshut"   NE "-222F--"   NE "MLL-Sonderzug zur Faszination Modellbau"
/*11*/     SL "11:27"   NE "DD 313"   NE "Entenhausen"   NE "Duckburg"   NE "Onkel Dagobert"   NE "--313--"   NE "Keine Mitfahrt f\374r Panzerknacker"

; // End of the Text_Messages string
